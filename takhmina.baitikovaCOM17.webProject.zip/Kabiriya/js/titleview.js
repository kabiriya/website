Splitting();

$('#btn_click').on('click', function() { window.location = 'http://www.google.com'; });